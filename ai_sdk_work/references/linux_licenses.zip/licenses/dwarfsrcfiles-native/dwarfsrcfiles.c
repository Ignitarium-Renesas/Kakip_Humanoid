// dwarfsrcfiles.c - Get source files associated with the dwarf in a elf file.
// gcc -Wall -g -O2 -lelf -ldw -o dwarfsrcfiles dwarfsrcfiles.c 
//
// Copyright (C) 2011, Mark Wielaard <mjw@redhat.com>
//
// This file is free software.  You can redistribute it and/or modify
// it under the terms of the GNU General Public License (GPL); either
// version 2, or (at your option) any later version.
