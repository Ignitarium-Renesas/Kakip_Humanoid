#!/usr/bin/env python3
# encoding: utf-8
import time
import serial

def serial_test(port, baudrate):
    try:
        # Initialize serial connection
        ser = serial.Serial(port, baudrate, timeout=1)
        print(f"Opened serial port {port} at {baudrate} baud.")

        while True:
            try:
                # Write data to serial port
                ser.write(b'Bensaaa')
                print("Sent: Bensaaa")
                #time.sleep(1)
            except serial.SerialException as e:
                print(f"Error during communication: {e}")
                break

    except serial.SerialException as e:
        print(f"Failed to open serial port {port} with baudrate {baudrate}: {e}")

    finally:
        # Ensure the serial port is closed
        if 'ser' in locals() and ser.is_open:
            ser.close()
            print("Serial port closed.")

if __name__ == "__main__":
    serial_test('/dev/ttySC2', 115200)
