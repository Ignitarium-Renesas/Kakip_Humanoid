#!/usr/bin/env python3
# encoding: utf-8

import time
import argparse
from gpio import GPIOPin  # Ensure this is the correct import for your GPIO library

def main(port, pin):
    # Initialize the GPIO pin
    tx_pin = GPIOPin(port, pin, 'out')  # Assuming 0 represents LOW

    while True:
        # Set the pin HIGH
        tx_pin.write(1)
        time.sleep(0.2)

        # Set the pin LOW
        tx_pin.write(0)
        time.sleep(0.2)

if __name__ == "__main__":
    # Set up argument parsing
    parser = argparse.ArgumentParser(description="GPIO Toggle Script")
    parser.add_argument("port", type=int, help="GPIO port number")
    parser.add_argument("pin", type=int, help="GPIO pin number")

    args = parser.parse_args()

    # Run the main function with provided arguments
    main(args.port, args.pin)
