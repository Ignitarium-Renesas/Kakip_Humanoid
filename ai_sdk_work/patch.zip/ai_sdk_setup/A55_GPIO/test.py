from time import sleep
from motion_manager import *

motion_manager = MotionManager()
motion_manager.run_action('greet')
sleep(0.5)
motion_manager.run_action('greet')
sleep(0.5)
motion_manager.run_action('greet')
sleep(0.5)
motion_manager.run_action('greet')
sleep(0.5)
